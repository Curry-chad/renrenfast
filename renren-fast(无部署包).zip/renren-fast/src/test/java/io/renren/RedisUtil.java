package io.renren;


import redis.clients.jedis.Jedis;

public class RedisUtil {

    public static void main(String[] args) {
        Jedis jedis  = new Jedis("106.13.107.156",6379);
        String ping = jedis.ping();
        System.out.println(ping);
        jedis.set("aaa","chenweilong");

        String aaa = jedis.get("aaa");

        System.out.println(aaa);
    }
}
